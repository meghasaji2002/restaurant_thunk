import React from 'react'
import { Col, Row } from 'react-bootstrap'
import ListGroup from 'react-bootstrap/ListGroup';
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import RestReview from '../components/RestReview';

function RestView() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <div className='container'>
      <Row>
    <Col  sm={6} md={4}>
    <img width={"90%"} height={"500px"} className='p-4' src="https://images.pexels.com/photos/1199957/pexels-photo-1199957.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />
    
    
    </Col>

<Col className='p-4'>

<hr />

<h2 style={{textAlign:"center"}}>restaurant</h2>
<hr />
<ListGroup className='border border-dark'>
  <h2 className='mt-3'  style={{textAlign:"center"}} >Reastaurant Name</h2>
      <ListGroup.Item>Neighbourhood : </ListGroup.Item>
      <ListGroup.Item>Cuisine_type : </ListGroup.Item>
      <ListGroup.Item>Address : </ListGroup.Item>
     
    </ListGroup>

    <div className='mt-3 text-center'>
      <button onClick={handleShow} type="button" class="btn btn-outline-success">Operating Hours</button>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title className='text-danger'>Operating Hours</Modal.Title>
        </Modal.Header>
        <Modal.Body><ListGroup>
      <ListGroup.Item>Monday : </ListGroup.Item>
      <ListGroup.Item>Tuesday : </ListGroup.Item>
      <ListGroup.Item>Wednesday : </ListGroup.Item>
      <ListGroup.Item>Thursday : </ListGroup.Item>
      <ListGroup.Item>Friday : </ListGroup.Item>
      <ListGroup.Item>Saturday : </ListGroup.Item>
      <ListGroup.Item>Sunday : </ListGroup.Item>

    </ListGroup></Modal.Body>
      </Modal>
      <RestReview/>
</div>





</Col>
<Col md={1}></Col>

      </Row>






    </div>
  )
}

export default RestView
