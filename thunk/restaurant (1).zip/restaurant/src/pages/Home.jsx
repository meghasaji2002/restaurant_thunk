import React, { useEffect } from 'react'
import { Col, Row } from 'react-bootstrap'
import RestCard from '../components/RestCard'
import { useDispatch, useSelector } from 'react-redux'
import { fetchrestaurant } from '../redux/restaurantSlice'

function Home() {

  const allrestaurant = useSelector((state)=>state.restaurantSlice.allrestaurant)
  console.log(allrestaurant);

  const dispatch = useDispatch()

  useEffect(()=>{

    dispatch(fetchrestaurant())



  },[])
  return (
    
  <Row className='p-3 my-5'>
            {allrestaurant?.length>0 ?
            allrestaurant.map ((restaurant)=> (<Col sm={6} md={4} className='px-5 py-3'>
                <RestCard restaurant={restaurant}/>
            </Col >)):<p>nothing to diplay</p>}
            
        </Row>

    
  )
}

export default Home
