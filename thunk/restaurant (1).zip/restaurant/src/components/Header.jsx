import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
  return (
    <>
    <nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand ms-2" href="#"><img height={'70px'} width={"70px"} src="https://img.freepik.com/premium-vector/animated-chef-logo-template_434010-35.jpg?w=740" alt="" /></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <Link to={'/'} class="nav-link active me-5" href="#" ><h2 className='fw-bold text-white'>AUTHE<span style={{color:'red'}}>NTIC</span></h2>
            <span class="visually-hidden">(current)</span>
          </Link>
        </li>
       
      </ul>
      <form class="d-flex me-5 ">
        <input class="form-control me-sm-2 text-dark" type="search" placeholder=""/>
        <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
      </form>
      
    </div>
  </div>
</nav></>
  )
}

export default Header
