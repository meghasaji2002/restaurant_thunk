import React, { useState } from 'react'
import Collapse from 'react-bootstrap/Collapse';

function RestReview() {
  const [open,setOpen] = useState(false);
  return (
    <>
    <button onClick={()=>setOpen(!open)} type="button" class="btn btn-outline-info ms-3">Click here to View the Reviews</button>
    
    <Collapse in={open}>
    <div>

<hr />
<h5>Name - Date</h5>
<p>rating</p>
<p>Discription</p>


</div>
      </Collapse>

</>
  )
}

export default RestReview
